const SIZE = 8;
const WORDS = ['CAT', 'DOG', 'SUN', 'FISH', 'BIRD'];
let grid = [];
let found = [];
let selecting = [];

function makeGrid() {
    grid = [];
    for (let i = 0; i < SIZE; i++) {
        grid[i] = [];
        for (let j = 0; j < SIZE; j++) {
            grid[i][j] = '';
        }
    }

    // Place words
    WORDS.forEach(word => {
        let placed = false;
        while (!placed) {
            let row = Math.floor(Math.random() * SIZE);
            let col = Math.floor(Math.random() * SIZE);
            let dir = Math.random() < 0.5 ? 0 : 1; // 0=horizontal, 1=vertical

            if (dir === 0 && col + word.length <= SIZE) {
                let canPlace = true;
                for (let i = 0; i < word.length; i++) {
                    if (grid[row][col + i] !== '') {
                        canPlace = false;
                        break;
                    }
                }
                if (canPlace) {
                    for (let i = 0; i < word.length; i++) {
                        grid[row][col + i] = word[i];
                    }
                    placed = true;
                }
            } else if (dir === 1 && row + word.length <= SIZE) {
                let canPlace = true;
                for (let i = 0; i < word.length; i++) {
                    if (grid[row + i][col] !== '') {
                        canPlace = false;
                        break;
                    }
                }
                if (canPlace) {
                    for (let i = 0; i < word.length; i++) {
                        grid[row + i][col] = word[i];
                    }
                    placed = true;
                }
            }
        }
    });

    // Fill empty cells
    for (let i = 0; i < SIZE; i++) {
        for (let j = 0; j < SIZE; j++) {
            if (grid[i][j] === '') {
                grid[i][j] = String.fromCharCode(65 + Math.floor(Math.random() * 26));
            }
        }
    }

    showGrid();
}

function showGrid() {
    const gridDiv = document.getElementById('grid');
    gridDiv.innerHTML = '';
    
    for (let i = 0; i < SIZE; i++) {
        for (let j = 0; j < SIZE; j++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.textContent = grid[i][j];
            cell.onclick = () => selectCell(i, j, cell);
            gridDiv.appendChild(cell);
        }
    }
}

function selectCell(row, col, cell) {
    selecting.push({row, col, cell});
    cell.style.background = 'yellow';
    
    const word = selecting.map(s => grid[s.row][s.col]).join('');
    
    if (WORDS.includes(word) && !found.includes(word)) {
        found.push(word);
        selecting.forEach(s => s.cell.classList.add('found'));
        document.getElementById('word-' + word).classList.add('found');
        document.getElementById('score').textContent = found.length;
        selecting = [];
        
        if (found.length === WORDS.length) {
            setTimeout(() => alert('You Win!'), 100);
        }
    } else if (selecting.length > 5) {
        selecting.forEach(s => {
            if (!s.cell.classList.contains('found')) {
                s.cell.style.background = 'white';
            }
        });
        selecting = [];
    }
}

function newGame() {
    found = [];
    selecting = [];
    document.getElementById('score').textContent = '0';
    document.querySelectorAll('.word').forEach(w => w.classList.remove('found'));
    makeGrid();
}

makeGrid();